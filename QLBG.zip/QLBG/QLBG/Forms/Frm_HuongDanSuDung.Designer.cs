﻿namespace QLBG.Forms
{
    partial class Frm_HuongDanSuDung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnThoat = new Button();
            lblGioiThieu = new Label();
            label1 = new Label();
            label = new Label();
            panel2 = new Panel();
            lblLoiCamOn = new Label();
            panel3 = new Panel();
            llbNhaCungCap = new LinkLabel();
            llbNhanVien = new LinkLabel();
            llbBaoCaoThongKe = new LinkLabel();
            llbHoaDonBanHang = new LinkLabel();
            llbKhachHang = new LinkLabel();
            llbMain = new LinkLabel();
            llbLoaiGiay = new LinkLabel();
            llbDangNhap = new LinkLabel();
            label23 = new Label();
            label17 = new Label();
            label22 = new Label();
            label14 = new Label();
            label7 = new Label();
            label21 = new Label();
            label20 = new Label();
            label16 = new Label();
            label19 = new Label();
            label15 = new Label();
            label18 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(btnThoat);
            panel1.Controls.Add(lblGioiThieu);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(label);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(719, 103);
            panel1.TabIndex = 0;
            // 
            // btnThoat
            // 
            btnThoat.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            btnThoat.Image = Properties.Resources.exit16;
            btnThoat.Location = new Point(650, 0);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(69, 25);
            btnThoat.TabIndex = 14;
            btnThoat.Text = "Thoát";
            btnThoat.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click;
            // 
            // lblGioiThieu
            // 
            lblGioiThieu.AutoSize = true;
            lblGioiThieu.Font = new Font("Segoe UI", 11.25F);
            lblGioiThieu.Location = new Point(190, 37);
            lblGioiThieu.Name = "lblGioiThieu";
            lblGioiThieu.Size = new Size(477, 20);
            lblGioiThieu.TabIndex = 1;
            lblGioiThieu.Text = "đây là ứng dụng giúp người sử dụng dễ dàng quản lí thông tin về giầy,";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F);
            label1.Location = new Point(112, 67);
            label1.Name = "label1";
            label1.Size = new Size(529, 20);
            label1.TabIndex = 0;
            label1.Text = "nhân viên và khách hàng  để dễ dàng thay đổi chiến lược để thu hút khách hơn.";
            // 
            // label
            // 
            label.AutoSize = true;
            label.Font = new Font("Segoe UI", 11.25F);
            label.Location = new Point(12, 37);
            label.Name = "label";
            label.Size = new Size(182, 20);
            label.TabIndex = 0;
            label.Text = "Giới thiệu sơ về ứng dụng:";
            // 
            // panel2
            // 
            panel2.Controls.Add(lblLoiCamOn);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 705);
            panel2.Name = "panel2";
            panel2.Size = new Size(719, 34);
            panel2.TabIndex = 1;
            // 
            // lblLoiCamOn
            // 
            lblLoiCamOn.AutoSize = true;
            lblLoiCamOn.Font = new Font("Segoe UI", 9.75F, FontStyle.Underline, GraphicsUnit.Point, 0);
            lblLoiCamOn.Location = new Point(343, 8);
            lblLoiCamOn.Name = "lblLoiCamOn";
            lblLoiCamOn.Size = new Size(373, 17);
            lblLoiCamOn.TabIndex = 0;
            lblLoiCamOn.Text = "Mọi chi tiết thắc mắc xin liên hệ: supportShopGiay@support.vn";
            // 
            // panel3
            // 
            panel3.Controls.Add(llbNhaCungCap);
            panel3.Controls.Add(llbNhanVien);
            panel3.Controls.Add(llbBaoCaoThongKe);
            panel3.Controls.Add(llbHoaDonBanHang);
            panel3.Controls.Add(llbKhachHang);
            panel3.Controls.Add(llbMain);
            panel3.Controls.Add(llbLoaiGiay);
            panel3.Controls.Add(llbDangNhap);
            panel3.Controls.Add(label23);
            panel3.Controls.Add(label17);
            panel3.Controls.Add(label22);
            panel3.Controls.Add(label14);
            panel3.Controls.Add(label7);
            panel3.Controls.Add(label21);
            panel3.Controls.Add(label20);
            panel3.Controls.Add(label16);
            panel3.Controls.Add(label19);
            panel3.Controls.Add(label15);
            panel3.Controls.Add(label18);
            panel3.Controls.Add(label13);
            panel3.Controls.Add(label12);
            panel3.Controls.Add(label11);
            panel3.Controls.Add(label10);
            panel3.Controls.Add(label9);
            panel3.Controls.Add(label8);
            panel3.Controls.Add(label6);
            panel3.Controls.Add(label5);
            panel3.Controls.Add(label4);
            panel3.Controls.Add(label3);
            panel3.Controls.Add(label2);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(0, 103);
            panel3.Name = "panel3";
            panel3.Size = new Size(719, 602);
            panel3.TabIndex = 2;
            // 
            // llbNhaCungCap
            // 
            llbNhaCungCap.AutoSize = true;
            llbNhaCungCap.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            llbNhaCungCap.Location = new Point(26, 271);
            llbNhaCungCap.Name = "llbNhaCungCap";
            llbNhaCungCap.Size = new Size(226, 20);
            llbNhaCungCap.TabIndex = 9;
            llbNhaCungCap.TabStop = true;
            llbNhaCungCap.Text = "Xem thêm cách sử dụng tại đây...";
            llbNhaCungCap.LinkClicked += llbNhaCungCap_LinkClicked;
            // 
            // llbNhanVien
            // 
            llbNhanVien.AutoSize = true;
            llbNhanVien.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            llbNhanVien.Location = new Point(160, 350);
            llbNhanVien.Name = "llbNhanVien";
            llbNhanVien.Size = new Size(226, 20);
            llbNhanVien.TabIndex = 8;
            llbNhanVien.TabStop = true;
            llbNhanVien.Text = "Xem thêm cách sử dụng tại đây...";
            llbNhanVien.LinkClicked += llbNhanVien_LinkClicked;
            // 
            // llbBaoCaoThongKe
            // 
            llbBaoCaoThongKe.AutoSize = true;
            llbBaoCaoThongKe.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            llbBaoCaoThongKe.Location = new Point(160, 562);
            llbBaoCaoThongKe.Name = "llbBaoCaoThongKe";
            llbBaoCaoThongKe.Size = new Size(226, 20);
            llbBaoCaoThongKe.TabIndex = 7;
            llbBaoCaoThongKe.TabStop = true;
            llbBaoCaoThongKe.Text = "Xem thêm cách sử dụng tại đây...";
            llbBaoCaoThongKe.LinkClicked += llbBaoCaoThongKe_LinkClicked;
            // 
            // llbHoaDonBanHang
            // 
            llbHoaDonBanHang.AutoSize = true;
            llbHoaDonBanHang.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            llbHoaDonBanHang.Location = new Point(161, 491);
            llbHoaDonBanHang.Name = "llbHoaDonBanHang";
            llbHoaDonBanHang.Size = new Size(226, 20);
            llbHoaDonBanHang.TabIndex = 6;
            llbHoaDonBanHang.TabStop = true;
            llbHoaDonBanHang.Text = "Xem thêm cách sử dụng tại đây...";
            llbHoaDonBanHang.LinkClicked += llbHoaDonBanHang_LinkClicked;
            // 
            // llbKhachHang
            // 
            llbKhachHang.AutoSize = true;
            llbKhachHang.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            llbKhachHang.Location = new Point(161, 424);
            llbKhachHang.Name = "llbKhachHang";
            llbKhachHang.Size = new Size(226, 20);
            llbKhachHang.TabIndex = 5;
            llbKhachHang.TabStop = true;
            llbKhachHang.Text = "Xem thêm cách sử dụng tại đây...";
            llbKhachHang.LinkClicked += llbKhachHang_LinkClicked;
            // 
            // llbMain
            // 
            llbMain.AutoSize = true;
            llbMain.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            llbMain.Location = new Point(130, 142);
            llbMain.Name = "llbMain";
            llbMain.Size = new Size(226, 20);
            llbMain.TabIndex = 4;
            llbMain.TabStop = true;
            llbMain.Text = "Xem thêm cách sử dụng tại đây...";
            llbMain.LinkClicked += llbMain_LinkClicked;
            // 
            // llbLoaiGiay
            // 
            llbLoaiGiay.AutoSize = true;
            llbLoaiGiay.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            llbLoaiGiay.Location = new Point(27, 202);
            llbLoaiGiay.Name = "llbLoaiGiay";
            llbLoaiGiay.Size = new Size(226, 20);
            llbLoaiGiay.TabIndex = 3;
            llbLoaiGiay.TabStop = true;
            llbLoaiGiay.Text = "Xem thêm cách sử dụng tại đây...";
            llbLoaiGiay.LinkClicked += llbLoaiGiay_LinkClicked;
            // 
            // llbDangNhap
            // 
            llbDangNhap.AutoSize = true;
            llbDangNhap.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            llbDangNhap.Location = new Point(27, 77);
            llbDangNhap.Name = "llbDangNhap";
            llbDangNhap.Size = new Size(226, 20);
            llbDangNhap.TabIndex = 2;
            llbDangNhap.TabStop = true;
            llbDangNhap.Text = "Xem thêm cách sử dụng tại đây...";
            llbDangNhap.LinkClicked += llbDangNhap_LinkClicked;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Segoe UI", 11.25F);
            label23.Location = new Point(25, 562);
            label23.Name = "label23";
            label23.Size = new Size(129, 20);
            label23.TabIndex = 1;
            label23.Text = "tìm kiếm theo tên.";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 11.25F);
            label17.Location = new Point(25, 424);
            label17.Name = "label17";
            label17.Size = new Size(129, 20);
            label17.TabIndex = 1;
            label17.Text = "tìm kiếm theo tên.";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Segoe UI", 11.25F);
            label22.Location = new Point(26, 491);
            label22.Name = "label22";
            label22.Size = new Size(129, 20);
            label22.TabIndex = 1;
            label22.Text = "tìm kiếm theo tên.";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 11.25F);
            label14.Location = new Point(27, 350);
            label14.Name = "label14";
            label14.Size = new Size(129, 20);
            label14.TabIndex = 1;
            label14.Text = "tìm kiếm theo tên.";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11.25F);
            label7.Location = new Point(25, 142);
            label7.Name = "label7";
            label7.Size = new Size(99, 20);
            label7.TabIndex = 1;
            label7.Text = "khách hàng,....";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 11.25F);
            label21.Location = new Point(303, 533);
            label21.Name = "label21";
            label21.Size = new Size(413, 20);
            label21.TabIndex = 1;
            label21.Text = "Tại đây chỉ xem được trong kho đã còn những sản phẩm nào.";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 11.25F);
            label20.Location = new Point(14, 533);
            label20.Name = "label20";
            label20.Size = new Size(292, 20);
            label20.TabIndex = 1;
            label20.Text = "-Giao diện báo cáo doanh thu và thống kê:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 11.25F);
            label16.Location = new Point(170, 392);
            label16.Name = "label16";
            label16.Size = new Size(514, 20);
            label16.TabIndex = 1;
            label16.Text = "Tại đây sẽ có những chức năng thêm, xóa, sửa, lưu, hủy bỏ, thoát, xuất excel, \r\n";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 11.25F);
            label19.Location = new Point(220, 462);
            label19.Name = "label19";
            label19.Size = new Size(464, 20);
            label19.TabIndex = 1;
            label19.Text = "Tại đây sẽ có những chức năng lập hóa đơn mới, sửa, xóa, xuất excel.\r\n";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 11.25F);
            label15.Location = new Point(13, 392);
            label15.Name = "label15";
            label15.Size = new Size(161, 20);
            label15.TabIndex = 1;
            label15.Text = "-Giao diện khách hàng:";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 11.25F);
            label18.Location = new Point(14, 462);
            label18.Name = "label18";
            label18.Size = new Size(207, 20);
            label18.TabIndex = 1;
            label18.Text = "-Giao diện hóa đơn bán hàng:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 11.25F);
            label13.Location = new Point(160, 321);
            label13.Name = "label13";
            label13.Size = new Size(514, 20);
            label13.TabIndex = 1;
            label13.Text = "Tại đây sẽ có những chức năng thêm, xóa, sửa, lưu, hủy bỏ, thoát, xuất excel, \r\n";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 11.25F);
            label12.Location = new Point(15, 321);
            label12.Name = "label12";
            label12.Size = new Size(149, 20);
            label12.TabIndex = 1;
            label12.Text = "-Giao diện nhân viên:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 11.25F);
            label11.Location = new Point(190, 249);
            label11.Name = "label11";
            label11.Size = new Size(437, 20);
            label11.TabIndex = 1;
            label11.Text = "Tại đây sẽ có những chức năng thêm, xóa, sửa, lưu, hủy bỏ, thoát.\r\n";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 11.25F);
            label10.Location = new Point(15, 249);
            label10.Name = "label10";
            label10.Size = new Size(174, 20);
            label10.TabIndex = 1;
            label10.Text = "-Giao diện nhà cung cấp:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 11.25F);
            label9.Location = new Point(160, 182);
            label9.Name = "label9";
            label9.Size = new Size(437, 20);
            label9.TabIndex = 1;
            label9.Text = "Tại đây sẽ có những chức năng thêm, xóa, sửa, lưu, hủy bỏ, thoát.\r\n";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 11.25F);
            label8.Location = new Point(15, 182);
            label8.Name = "label8";
            label8.Size = new Size(143, 20);
            label8.TabIndex = 1;
            label8.Text = "-Giao diện loại giầy:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11.25F);
            label6.Location = new Point(140, 113);
            label6.Name = "label6";
            label6.Size = new Size(522, 20);
            label6.TabIndex = 1;
            label6.Text = "Tại đây chọn những chức năng chính mà hệ thống có như: hóa đơn, nhân viên,";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F);
            label5.Location = new Point(15, 113);
            label5.Name = "label5";
            label5.Size = new Size(125, 20);
            label5.TabIndex = 1;
            label5.Text = "- Giao diện chính:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F);
            label4.Location = new Point(112, 48);
            label4.Name = "label4";
            label4.Size = new Size(550, 20);
            label4.TabIndex = 1;
            label4.Text = "Tại đây nhập tài khoản và mật khẩu để được sử dụng các chức năng của hệ thống.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F);
            label3.Location = new Point(15, 48);
            label3.Name = "label3";
            label3.Size = new Size(95, 20);
            label3.TabIndex = 1;
            label3.Text = "- Đăng nhập:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F);
            label2.Location = new Point(12, 17);
            label2.Name = "label2";
            label2.Size = new Size(101, 20);
            label2.TabIndex = 0;
            label2.Text = "Cách sử dụng:";
            // 
            // Frm_HuongDanSuDung
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(719, 739);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Frm_HuongDanSuDung";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hướng Dẫn Sử Dụng";
            Load += HuongDanSuDung_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label;
        private Label lblLoiCamOn;
        private Label lblGioiThieu;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label lblDangNhap;
        private LinkLabel llbDangNhap;
        private Button btnThoat;
        private Label label6;
        private Label label5;
        private Label label7;
        private Label label9;
        private Label label8;
        private Label label11;
        private Label label10;
        private Label label13;
        private Label label12;
        private Label label14;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label23;
        private Label label22;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label18;
        private LinkLabel llbLoaiGiay;
        private LinkLabel llbNhaCungCap;
        private LinkLabel llbNhanVien;
        private LinkLabel llbBaoCaoThongKe;
        private LinkLabel llbHoaDonBanHang;
        private LinkLabel llbKhachHang;
        private LinkLabel llbMain;
    }
}